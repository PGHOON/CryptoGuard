struct data_t {
   int pid;
   int uid;
   char command[16];
   char message[32];
};